# 安装node.js

# 然后双击init.bat

# 然后双击start.bat
